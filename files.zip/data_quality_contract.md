# Data Quality Contract · Retail Orders

**Dataset:** `retail-orders-raw.csv` · **Producer:** order-capture / payments feed · **Consumer:** Revenue & Growth dashboards (KPI Dictionary K01-K10)
**Decision owner:** Head of Revenue & Growth · **Data steward:** Data Analytics team · **Version:** 1.0

This contract states what "trustworthy" means for the retail orders feed, the thresholds at which the feed is considered broken, and who acts when it is. Every rule is executable in `data_profile.ipynb` and tracked live in `kpi_dictionary.xlsx` (sheet `DQ_Checks`).

---

## 1. Rules, thresholds and severity

Pass rate = rows passing ÷ rows tested, per refresh. **WARN** = investigate within the stated time. **FAIL** = KPI refresh is blocked for affected metrics.

| # | Dimension | Rule (source: data dictionary) | Warn below | Fail below | Severity | Result on this extract |
|---|---|---|---|---|---|---|
| 1 | Completeness | `order_id` populated | 99.9% | 99.5% | Critical | 100% PASS |
| 2 | Completeness | `order_date` populated | 99.5% | 98% | Critical | 91.7% FAIL (RT-1011) |
| 3 | Completeness | `quantity`, `unit_price`, `payment_status` populated | 99.5% | 98% | Critical | 100% PASS |
| 4 | Completeness | `city` populated | 99% | 95% | Medium | 91.7% FAIL (RT-1005) |
| 5 | Completeness | `discount_pct` populated (blank = 0 only if justified, see §3) | 99% | 95% | Medium | 91.7% FAIL (RT-1003) |
| 6 | Uniqueness | `order_id` unique | 99.9% | 99.5% | Critical | 91.7% FAIL (RT-1004 twice) |
| 7 | Validity | `order_date` is ISO `yyyy-mm-dd`, between 2025-01-01 and today | 99% | 97% | Critical | 81.8% FAIL (RT-1002 format, RT-1006 month 13) |
| 8 | Validity | `quantity` is a whole number > 0 | 99.5% | 98% | Critical | 83.3% FAIL (RT-1006 = -1, RT-1008 = "two") |
| 9 | Validity | `unit_price` is a non-negative INR amount | 99.9% | 99.5% | Critical | 100% PASS |
| 10 | Validity | `discount_pct` between 0 and 100 | 99.5% | 98% | Critical | 90.9% FAIL (RT-1007 = 105) |
| 11 | Consistency | `payment_status`, `customer_segment`, `category` use canonical spelling | 99% | 95% | Medium | 91.7% FAIL (`paid`, `student`); 100% after normalisation |
| 12 | Freshness | Latest `order_date` is no older than 2 days | n/a | breach | Critical | FAIL: latest is 2026-01-18 (260 days old on 2026-10-05) |

*Why a "FAIL" here is expected:* the extract has 12 rows, so one bad row moves a pass rate by about 8 points, and it is a static training file, so freshness cannot pass. The thresholds are written for the production feed.

## 2. Failure handling (what the pipeline does automatically)

| Situation | Action |
|---|---|
| Case or whitespace differences (`paid`, `student`) | Normalise (trim, title-case) and log |
| `dd/mm/yyyy` date | Convert as day-first and flag `date repaired` |
| Exact duplicate row | Keep first copy, drop the rest, log in `Quarantine` |
| Any **Critical** rule fails on a row | Row is **quarantined**: excluded from every KPI, listed with its reason |
| **Medium** rule fails on a row | Row stays in; excluded only from slices that need the field (e.g. city) |

## 3. Documented exceptions

* **Blank `discount_pct` is treated as 0 only on `Pending` orders.** Justification: no revenue is recognised on Pending orders, so the assumption cannot change reported revenue. A blank on any other status is a Critical failure.
* **Day-first dates:** `03/01/2026` is read as 3 Jan 2026 because sequential order IDs place it between 3 Jan and 5 Jan.
* Words in numeric fields (`"two"`) are **not** auto-converted; they are quarantined so a person confirms the intended value.

## 4. Escalation

| Level | Trigger | Who is told | Within | Required action |
|---|---|---|---|---|
| **L1: Warn** | Any rule below its warn threshold but above fail | Data steward (ticket) | 1 business day | Find the source of the defect; record in the log; no refresh block |
| **L2: Fail** | Any rule below its fail threshold | Data steward + Head of Revenue & Growth (message) | 4 hours | Block refresh of affected KPIs, keep last good values on the dashboard with a "stale data" banner, raise a fix with the order-capture team |
| **L3: Revenue risk** | Quarantined rows with `payment_status = Paid` exceed 1% of Paid orders, **or** freshness fails for more than 24 hours | Finance Controller + Head of Revenue & Growth (call) | Same day | Reconcile against the payment gateway before any revenue figure is shared externally |
| **Close-out** | Rule back at or above warn level for 2 consecutive refreshes | Data steward | n/a | Close ticket, add the root cause and fix to the log |

## 5. Ownership and review

| Role | Responsibility |
|---|---|
| Producer (order-capture team) | Fix defects at source: validation on date, quantity and discount entry; unique constraint on `order_id` |
| Data steward | Runs the checks each refresh, owns quarantine, keeps this contract current |
| Decision owner (Head of Revenue & Growth) | Accepts or changes thresholds; signs off any new exception |

The contract is reviewed quarterly, or after any Critical failure.

## 6. Open questions for the data owner

1. **`customer_segment`:** the dictionary says "Student Fresher or Professional". Is `Fresher` a separate segment from `Student` (3 values, as observed) or the same one (2 values)?
2. Should `Paid` orders with an invalid field be fixed at source and re-ingested, or corrected by Finance?
3. Are the freshness limit (2 days) and the 4-hour L2 response time realistic for the team?
