# RabTech Academy · Data Analytics & Business Intelligence Internship

Portfolio of practical-curriculum deliverables, all built on one retail orders dataset (`data/`).

| # | Task | Folder | Status |
|---|---|---|---|
| 01 | Publish internship offer on LinkedIn | n/a | Approved |
| 02 | KPI Dictionary & Data Quality Contract | [`task-02-kpi-dictionary`](task-02-kpi-dictionary) | Done |
| 03 | Data Ingestion, Cleaning & Preprocessing with Pandas | [`task-03-data-cleaning`](task-03-data-cleaning) | Done |
| 04 | Exploratory Data Analysis & Statistical Insights | `task-04-...` | Planned |
| 05 | Interactive Dashboard & KPI Visualizations | `task-05-...` | Planned |
| 06 | Executive Decision Report & Capstone | `task-06-...` | Planned |

## Task 02 contents
* `kpi_dictionary.xlsx`: 10 KPIs (formula, grain, filters, owner, refresh cadence) with live values, plus 14 live data-quality checks
* `data_profile.ipynb`: executable profiling of completeness, uniqueness, validity, consistency and freshness
* `data_quality_contract.md`: failure thresholds and escalation actions

## Task 03 contents
* `data_cleaning.ipynb`: step-by-step cleaning with before/after comparison (missing values, duplicates, data types, outliers, feature engineering)
* `clean_dataset.csv`: the cleaned, standardised dataset (10,316 rows, 28 columns)
* `quarantine_rows.csv`: rows removed with the reason for each (nothing is deleted silently)
* `cleaning_log.csv`: every cleaning step with its row count
* `generate_raw_dataset.py` and `data/retail_orders_raw_10k.csv`: the **synthetic** raw input (11,262 rows). Randomly generated with a fixed seed and deliberate defects; `unit_cost` is invented so profit margin can be calculated

## Run it
```bash
pip install pandas numpy matplotlib jupyter
cd task-02-kpi-dictionary && jupyter notebook data_profile.ipynb
cd ../task-03-data-cleaning && jupyter notebook data_cleaning.ipynb
```
