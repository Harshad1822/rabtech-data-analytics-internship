"""
Generate a messy, synthetic retail-orders dataset (10,000+ rows) for Task 03.

* SYNTHETIC: every row is randomly generated (seed fixed, so the file is reproducible).
* Same columns as the RabTech sample (retail-orders-raw.csv) plus `unit_cost`, which is
  needed to calculate profit margin. The cost values are invented for practice.
* Realistic defects are injected on purpose: duplicates, missing values written many ways,
  mixed date formats, currency symbols in numbers, words in numeric fields, impossible
  values, outliers and inconsistent spelling.

Run:  python generate_raw_dataset.py      -> writes retail_orders_raw_10k.csv
"""
from pathlib import Path
import numpy as np
import pandas as pd

rng = np.random.default_rng(2026)
N = 11_000                                          # unique orders (duplicates are added on top); sized so the CLEANED file still has 10,000+ rows

LIST_PRICE = {"Learning Kit": 799, "Course Access": 1499, "Mentor Session": 999}
CITIES = ["Mumbai", "Delhi", "Bengaluru", "Chennai", "Hyderabad", "Pune", "Kochi", "Kolkata", "Ahmedabad", "Jaipur"]
CITY_P = [0.17, 0.15, 0.17, 0.11, 0.11, 0.08, 0.05, 0.07, 0.05, 0.04]

# ---------------------------------------------------------------- clean "truth" table
days = pd.date_range("2025-01-01", "2026-09-30")
month_w = {1: 1.3, 6: 1.25, 7: 1.25, 12: 1.15}      # mild seasonality (admission season)
w = np.array([month_w.get(d.month, 1.0) for d in days]); w = w / w.sum()
dates = pd.Series(rng.choice(days, size=N, p=w)).sort_values().reset_index(drop=True)

cat = rng.choice(list(LIST_PRICE), size=N, p=[0.40, 0.35, 0.25])
seg = rng.choice(["Student", "Fresher", "Professional"], size=N, p=[0.45, 0.25, 0.30])
qty = rng.choice([1, 2, 3, 4, 5], size=N, p=[0.60, 0.25, 0.09, 0.04, 0.02])
price = pd.Series(cat).map(LIST_PRICE).to_numpy()
cost = np.round(price * rng.uniform(0.38, 0.55, size=N), 2)

disc = np.empty(N)
for s, p in {"Student": [.30, .20, .25, .15, .10], "Fresher": [.35, .25, .20, .12, .08], "Professional": [.55, .25, .12, .06, .02]}.items():
    m = seg == s
    disc[m] = rng.choice([0, 5, 10, 15, 20], size=m.sum(), p=p)

status = np.empty(N, dtype=object)
for c, p in {"Learning Kit": [.78, .08, .08, .06], "Course Access": [.75, .08, .08, .09], "Mentor Session": [.80, .08, .08, .04]}.items():
    m = cat == c
    status[m] = rng.choice(["Paid", "Pending", "Failed", "Refunded"], size=m.sum(), p=p)

city = rng.choice(CITIES, size=N, p=CITY_P)

# ---------------------------------------------------------------- turn everything into text, then break it
df = pd.DataFrame({
    "order_id": [f"RT-{1001 + i}" for i in range(N)],
    "order_date": dates.dt.strftime("%Y-%m-%d"),
    "customer_segment": seg, "city": city, "category": cat,
    "quantity": qty.astype(str), "unit_price": price.astype(str),
    "discount_pct": disc.astype(int).astype(str), "payment_status": status,
    "unit_cost": cost.astype(str),
}).astype(object)

def take(free, rate):
    """Pick `rate` of the rows that are still untouched in this column."""
    k = int(round(rate * N)); idx = rng.choice(np.flatnonzero(free), size=k, replace=False); free[idx] = False
    return idx
def blank(k): return rng.choice(["", "", "", "NA", "N/A", "null", "-"], size=k)    # missing, written many ways

# --- order_date
free = np.ones(N, bool); dt = dates.reset_index(drop=True)
i = take(free, .060); df.loc[i, "order_date"] = dt[i].dt.strftime("%d/%m/%Y")           # dd/mm/yyyy
i = take(free, .030); df.loc[i, "order_date"] = dt[i].dt.strftime("%d-%b-%Y")           # 05-Jan-2026
i = take(free, .005); df.loc[i, "order_date"] = rng.choice(["2026-13-10", "2025-02-30", "2026-00-15", "31/02/2026"], size=len(i))
i = take(free, .008); df.loc[i, "order_date"] = blank(len(i))
i = take(free, .002); df.loc[i, "order_date"] = rng.choice(["2027-03-14", "2028-01-09"], size=len(i))   # future dates

# --- customer_segment / category / payment_status spelling
for col, rates in {"customer_segment": (.12, .06, .04), "category": (.05, .00, .03), "payment_status": (.08, .04, .00)}.items():
    free = np.ones(N, bool)
    i = take(free, rates[0]); df.loc[i, col] = df.loc[i, col].str.lower()
    i = take(free, rates[1]); df.loc[i, col] = df.loc[i, col].str.upper()
    i = take(free, rates[2]); df.loc[i, col] = df.loc[i, col] + " "
free = np.ones(N, bool); i = take(free, .006); df.loc[i, "payment_status"] = blank(len(i))

# --- city
free = np.ones(N, bool)
blr = np.flatnonzero((df["city"] == "Bengaluru").to_numpy() & free)
df.loc[rng.choice(blr, size=int(len(blr) * .25), replace=False), "city"] = "Bangalore"
cok = np.flatnonzero((df["city"] == "Kochi").to_numpy())
df.loc[rng.choice(cok, size=int(len(cok) * .20), replace=False), "city"] = "Cochin"
i = take(free, .05); df.loc[i, "city"] = df.loc[i, "city"].str.lower()
i = take(free, .03); df.loc[i, "city"] = df.loc[i, "city"].str.upper()
i = take(free, .02); df.loc[i, "city"] = " " + df.loc[i, "city"]
i = take(free, .015); df.loc[i, "city"] = blank(len(i))

# --- quantity
free = np.ones(N, bool)
i = take(free, .010); df.loc[i, "quantity"] = rng.choice(["one", "two", "three"], size=len(i))
i = take(free, .003); df.loc[i, "quantity"] = rng.choice(["-1", "-2"], size=len(i))
i = take(free, .002); df.loc[i, "quantity"] = "0"
i = take(free, .0015); df.loc[i, "quantity"] = rng.choice(["100", "250", "500", "999"], size=len(i))     # outliers
i = take(free, .003); df.loc[i, "quantity"] = blank(len(i))

# --- unit_price
free = np.ones(N, bool)
i = take(free, .03); df.loc[i, "unit_price"] = blank(len(i))
i = take(free, .03); df.loc[i, "unit_price"] = ["₹{:,}".format(int(float(v))) for v in df.loc[i, "unit_price"]]   # ₹1,499
i = take(free, .004); df.loc[i, "unit_price"] = [str(int(float(v)) * 100) for v in df.loc[i, "unit_price"]]      # decimal-shift outlier
i = take(free, .002); df.loc[i, "unit_price"] = ["-" + str(int(float(v))) for v in df.loc[i, "unit_price"]]      # negative price

# --- discount_pct
free = np.ones(N, bool)
i = take(free, .020); df.loc[i, "discount_pct"] = blank(len(i))
i = take(free, .040); df.loc[i, "discount_pct"] = df.loc[i, "discount_pct"] + "%"
i = take(free, .0025); df.loc[i, "discount_pct"] = rng.choice(["105", "150"], size=len(i))
i = take(free, .0015); df.loc[i, "discount_pct"] = "-10"

# --- unit_cost
free = np.ones(N, bool)
i = take(free, .03); df.loc[i, "unit_cost"] = blank(len(i))
i = take(free, .003); df.loc[i, "unit_cost"] = rng.choice(["0", "-50"], size=len(i))

# ---------------------------------------------------------------- duplicates
pos = np.arange(N, dtype=float)
exact = rng.choice(N, size=250, replace=False)
copies = df.loc[exact].copy(); copies.index = exact + 0.5
lower_ids = rng.choice(copies.index, size=40, replace=False)                            # same order, id typed in lower case
copies.loc[lower_ids, "order_id"] = copies.loc[lower_ids, "order_id"].str.lower()
conflict = rng.choice(np.setdiff1d(np.arange(N), exact), size=12, replace=False)        # same id, different quantity
conf = df.loc[conflict].copy(); conf.index = conflict + 0.5
conf["quantity"] = rng.choice(["7", "8", "9"], size=len(conf))
out = pd.concat([df, copies, conf]).sort_index().reset_index(drop=True)

path = Path(__file__).resolve().parent
target = path.parent / "data" if (path.parent / "data").exists() else path
out.to_csv(target / "retail_orders_raw_10k.csv", index=False)
print(f"Wrote {len(out):,} rows ({N:,} unique orders + {len(copies) + len(conf)} duplicate rows) to {target / 'retail_orders_raw_10k.csv'}")
